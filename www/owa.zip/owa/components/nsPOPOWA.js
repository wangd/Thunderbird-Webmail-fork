/*****************************  Globals   *************************************/
const nsOWAClassID = Components.ID("{112ebca0-0109-11da-8cd6-0800200c9a66}");
const nsOWAContactID = "@mozilla.org/POPOWA;1";
const ExtOWAGuid = "{3d82b2c0-0109-11da-8cd6-0800200c9a66}";


/******************************  OWA ***************************************/




function nsOWA()
{
    try
    {
        var scriptLoader =  Components.classes["@mozilla.org/moz/jssubscript-loader;1"]
        scriptLoader = scriptLoader.getService(Components.interfaces.mozIJSSubScriptLoader);
        scriptLoader.loadSubScript("chrome://web-mail/content/common/DebugLog.js");
        scriptLoader.loadSubScript("chrome://web-mail/content/common/CommonPrefs.js");
        scriptLoader.loadSubScript("chrome://web-mail/content/common/HttpComms3.js");


        var date = new Date();
        var  szLogFileName = "OWA Log - " + date.getHours()+ "-" + date.getMinutes() + "-"+ date.getUTCMilliseconds() +" -";
        this.m_Log = new DebugLog("webmail.logging.comms", ExtOWAGuid, szLogFileName);

        this.m_Log.Write("nsOWA.js - Constructor - START");

        this.m_bAuthorised = false;
        this.m_szUserName = null;
        this.m_szPassWord = null;
        this.m_oResponseStream = null;
        this.m_HttpComms = new HttpComms(this.m_Log);
        this.m_iStage = 0;

        this.m_Log.Write("nsOWA.js - Constructor - END");
    }
    catch(e)
    {
        DebugDump("nsOWA.js: Constructor : Exception : "
                                      + e.name
                                      + ".\nError message: "
                                      + e.message);
    }
}



nsOWA.prototype =
{
    get userName() {return this.m_szUserName;},
    set userName(userName) {return this.m_szUserName = userName;},

    get passWord() {return this.m_szPassWord;},
    set passWord(passWord) {return this.m_szPassWord = passWord;},

    get bAuthorised() {return this.m_bAuthorised;},

    get ResponseStream() {return this.m_oResponseStream;},
    set ResponseStream(responseStream) {return this.m_oResponseStream = responseStream;},





    logIn : function()
    {
        try
        {
            this.m_Log.Write("nsOWA.js - logIN - START");
            this.m_Log.Write("nsOWA.js - logIN - Username: " + this.m_szUserName
                                                   + " Password: " + this.m_szPassWord
                                                   + " stream: " + this.m_oResponseStream);

            if (!this.m_szUserName || !this.m_oResponseStream  || !this.m_szPassWord) return false;

            this.m_HttpComms.setURI("/*add login url here*/");
            this.m_HttpComms.setRequestMethod("GET");
            var bResult = this.m_HttpComms.send(this.loginOnloadHandler, this);
            if (!bResult) throw new Error("httpConnection returned false");

            this.m_Log.Write("nsOWA.js - logIN - END");
            return true;
        }
        catch(e)
        {
            this.m_Log.DebugDump("nsOWA.js: logIN : Exception : "
                                              + e.name +
                                              ".\nError message: "
                                              + e.message);
            return false;
        }
    },


    loginOnloadHandler : function(szResponse ,event , mainObject)
    {
        try
        {
            mainObject.m_Log.Write("nsOWA.js - loginOnloadHandler - START");


            mainObject.m_Log.Write("nsOWA.js - loginOnloadHandler - END");
        }
        catch(err)
        {
            mainObject.m_Log.DebugDump("nsOWA.js: loginHandler : Exception : "
                                          + err.name
                                          + ".\nError message: "
                                          + err.message);

            mainObject.serverComms("-ERR negative vibes\r\n");
        }
    },




    //stat
    //total size is in octets
    getNumMessages : function()
    {
        try
        {
            this.m_Log.Write("nsOWA.js - getNumMessages - START");


            this.m_Log.Write("nsOWA.js - getNumMessages - END");
            return true;
        }
        catch(e)
        {
            this.m_Log.DebugDump("nsOWA.js: getNumMessages : Exception : "
                                          + e.name
                                          + ".\nError message: "
                                          + e.message);
            return false;
        }
    },




    mailBoxOnloadHandler : function (szResponse ,event , mainObject)
    {
        try
        {
            mainObject.m_Log.Write("nsOWA.js - mailBoxOnloadHandler - START");

            mainObject.m_Log.Write("nsOWA.js - mailBoxOnloadHandler : "
                                         + mainObject.m_iStage + "\n"
                                         + szResponse);


            mainObject.m_Log.Write("nsOWA.js - MailBoxOnload - END");
        }
        catch(err)
        {
             mainObject.m_Log.DebugDump("nsOWA.js: MailboxOnload : Exception : "
                                              + err.name
                                              + ".\nError message: "
                                              + err.message);

             mainObject.serverComms("-ERR negative vibes\r\n");
        }
    },






    //list
    //i'm not downloading the mailbox again.
    //I hope stat been called first or there's going to be trouble
    getMessageSizes : function()
    {
        try
        {
            this.m_Log.Write("nsOWA.js - getMessageSizes - START");


            this.m_Log.Write("nsOWA.js - getMessageSizes - END");
            return true;
        }
        catch(e)
        {
            this.m_Log.DebugDump("nsOWA.js: getMessageSizes : Exception : "
                                          + e.name
                                          + ".\nError message: "
                                          + e.message);
            return false;
        }
    },



    //IUDL
    getMessageIDs : function()
    {
        try
        {
            this.m_Log.Write("nsOWA.js - getMessageIDs - START");


            this.m_Log.Write("nsOWA.js - getMessageIDs - END");
            return true;
        }
        catch(e)
        {
            this.m_Log.DebugDump("nsOWA.js: getMessageIDs : Exception : "
                                          + e.name
                                          + ".\nError message: "
                                          + e.message);
            return false;
        }
    },





    //retr
    getMessage : function( lID)
    {
        try
        {
            this.m_Log.Write("nsOWA.js - getMessage - START");
            this.m_Log.Write("nsOWA.js - getMessage - msg num" + lID);


            this.m_Log.Write("m_YahooLog.js - getMessage - END");
            return true;
        }
        catch(e)
        {
             this.m_Log.DebugDump("m_YahooLog.js: getMessage : Exception : "
                                          + e.name +
                                          ".\nError message: "
                                          + e.message);
            return false;
        }
    },


    emailOnloadHandler : function (szResponse ,event , mainObject)
    {
        try
        {
            mainObject.m_Log.Write("m_YahooLog.js - emailOnloadHandler - START");

            mainObject.m_Log.Write("m_YahooLog.js - emailOnloadHandler - msg :\n" + szResponse);

            mainObject.m_Log.Write("m_YahooLog.js - emailOnloadHandler - END");
        }
        catch(err)
        {
            mainObject.m_Log.DebugDump("m_YahooLog.js: emailOnloadHandler : Exception : "
                                          + err.name
                                          + ".\nError message: "
                                          + err.message);

            mainObject.serverComms("-ERR negative vibes\r\n");
        }
    },




    //dele
    deleteMessage : function(lID)
    {
        try
        {
            this.m_Log.Write("nsOWA.js - deleteMessage - START");
            this.m_Log.Write("nsOWA.js - deleteMessage - id " + lID );


            this.m_Log.Write("nsOWA.js - deleteMessage - END");
            return true;
        }
        catch(e)
        {
            this.m_Log.DebugDump("nsOWA.js: deleteMessage : Exception : "
                                          + e.name +
                                          ".\nError message: "
                                          + e.message);
            return false;
        }
    },


    deleteMessageOnloadHandler : function (szResponse ,event , mainObject)
    {
        try
        {
            mainObject.m_Log.Write("nsOWA.js - deleteMessageOnload - START");
            mainObject.m_Log.Write("nsOWA.js - deleteMessageOnload :\n" + szResponse);


            mainObject.serverComms("+OK its history\r\n");
            mainObject.m_Log.Write("nsOWA.js - deleteMessageOnload - END");
        }
        catch(e)
        {
            mainObject.m_Log.DebugDump("nsOWA.js: deleteMessageOnload : Exception : "
                                              + e.name
                                              + ".\nError message: "
                                              + e.message);
            mainObject.serverComms("-ERR negative vibes\r\n");
        }
    },



    //cookies are deleted when the connection ends so i dont need to download pages
    logOut : function()
    {
        try
        {
            this.m_Log.Write("nsOWA.js - logOUT - START");

            this.m_bAuthorised = false;
            this.serverComms("+OK Your Out\r\n");

            this.m_Log.Write("nsOWA.js - logOUT - END");
            return true;
        }
        catch(e)
        {
            this.m_Log.DebugDump("nsOWA.js: logOUT : Exception : "
                                      + e.name
                                      + ".\nError message: "
                                      + e.message);
            return false;
        }
    },





    serverComms : function (szMsg)
    {
        try
        {
            this.m_Log.Write("nsOWA.js - serverComms - START");
            this.m_Log.Write("nsOWA.js - serverComms msg " + szMsg);
            var iCount = this.m_oResponseStream.write(szMsg,szMsg.length);
            this.m_Log.Write("nsOWA.js - serverComms sent count: " + iCount
                                                        +" msg length: " +szMsg.length);
            this.m_Log.Write("nsOWA.js - serverComms - END");
        }
        catch(e)
        {
            this.m_Log.DebugDump("nsOWA.js: serverComms : Exception : "
                                              + e.name
                                              + ".\nError message: "
                                              + e.message);
        }
    },


/******************************************************************************/
/***************** XPCOM  stuff ***********************************************/
/******************************************************************************/
    QueryInterface : function (iid)
    {
        if (!iid.equals(Components.interfaces.nsIPOPDomainHandler)
                                      && !iid.equals(Components.interfaces.nsISupports))
            throw Components.results.NS_ERROR_NO_INTERFACE;

        return this;
    }
}


/******************************************************************************/
/* FACTORY*/
var nsOWAFactory = new Object();

nsOWAFactory.createInstance = function (outer, iid)
{
    if (outer != null) throw Components.results.NS_ERROR_NO_AGGREGATION;

    if (!iid.equals(nsOWAClassID) && !iid.equals(Components.interfaces.nsISupports))
        throw Components.results.NS_ERROR_INVALID_ARG;

    return new nsOWA();
}


/******************************************************************************/
/* MODULE */
var nsOWAModule = new Object();

nsOWAModule.registerSelf = function(compMgr, fileSpec, location, type)
{
    compMgr = compMgr.QueryInterface(Components.interfaces.nsIComponentRegistrar);
    compMgr.registerFactoryLocation(nsOWAClassID,
                                    "OWAComponent",
                                    nsOWAContactID,
                                    fileSpec,
                                    location,
                                    type);
}


nsOWAModule.unregisterSelf = function(aCompMgr, aFileSpec, aLocation)
{
    aCompMgr = aCompMgr.QueryInterface(Components.interfaces.nsIComponentRegistrar);
    aCompMgr.unregisterFactoryLocation(nsOWAClassID, aFileSpec);
}


nsOWAModule.getClassObject = function(compMgr, cid, iid)
{
    if (!cid.equals(nsOWAClassID))
        throw Components.results.NS_ERROR_NO_INTERFACE;

    if (!iid.equals(Components.interfaces.nsIFactory))
        throw Components.results.NS_ERROR_NOT_IMPLEMENTED;

    return nsOWAFactory;
}


nsOWAModule.canUnload = function(compMgr)
{
    return true;
}
/******************************************************************************/


function NSGetModule(compMgr, fileSpec)
{
    return nsOWAModule;
}
