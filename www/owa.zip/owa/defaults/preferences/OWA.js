pref("extensions.{3d82b2c0-0109-11da-8cd6-0800200c9a66}.description", "chrome://owa/locale/OWA.properties");

