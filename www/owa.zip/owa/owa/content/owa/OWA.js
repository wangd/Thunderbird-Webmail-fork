const cszOWAContentID = "@mozilla.org/POPOWA;1";


window.addEventListener("load", function() {gOWAStartUp.init();} , false);

var gOWAStartUp =
{
    m_DomainManager : null,
    m_Log : null,
    m_Timer : null,

    init : function ()
    {
        try
        {
            //create debug log global
            this.m_Log = new DebugLog("webmail.logging.comms",
                                      "{3c8e8390-2cf6-11d9-9669-0800200c9a66}",
                                      "owa");

            this.m_Log.Write("OWA.js : OWAStartUp - START");

            var iCount = this.windowCount();
            if (iCount >1)
            {
                this.m_Log.Write("Lycos.js : - another window - END");
                return;
            }

            try
            {
                this.m_DomainManager = Components.classes["@mozilla.org/DomainManager;1"]
                                                 .getService()
                                                 .QueryInterface(Components.interfaces.nsIDomainManager);
            }
            catch(err)
            {
                window.removeEventListener("load", function() {gOWAStartUp.init();} , false);
                throw new Error("Domain Manager Not Found");
            }

            this.m_Timer = Components.classes["@mozilla.org/timer;1"]
                                     .createInstance(Components.interfaces.nsITimer);
            this.m_Timer.initWithCallback(this,
                                          2000,
                                          Components.interfaces.nsITimer.TYPE_REPEATING_SLACK);
            this.m_Log.Write("OWA.js : OWAStartUp - DB not loaded");

            window.removeEventListener("load", function() {gOWAStartUp.init();} , false);

            this.m_Log.Write("OWA.js : OWAStartUP - END ");
        }
        catch(e)
        {
            this.m_Log.DebugDump("OWA.js : Exception in OWAStartUp "
                                        + e.name +
                                        ".\nError message: "
                                        + e.message);
        }
    },


    notify: function(timer)
    {
        try
        {
            this.m_Log.Write("OWA.js : TimerCallback -  START");

            if(!this.m_DomainManager.isReady())
            {
                this.m_Log.Write("Lcyos.js : notify -  db not ready");
                return;
            }
            timer.cancel();

            //get store ids
            this.idCheck("testDomain.com","POP", cszOWAContentID );


            this.m_Log.Write("OWA.js : TimerCallback - END");
        }
        catch(e)
        {
            this.m_Log.DebugDump("OWA.js : TimerCallback - Exception in notify : "
                                        + e.name +
                                        ".\nError message: "
                                        + e.message);
        }
    },


    idCheck : function(szDomain, szProtocol, szWantedContentID)
    {
        this.m_Log.Write("Lycos.js : idCheck - START");
        this.m_Log.Write("Lycos.js : idCheck - " +szDomain + " "
                                                + szProtocol+ " "
                                                + szWantedContentID);

        var szContentID = new Object;
        if (this.m_DomainManager.getDomainForProtocol(szDomain,szProtocol, szContentID))
        {
            this.m_Log.Write("Lycos.js : idCheck - found");
            if (szContentID.value != szWantedContentID)
            {
                this.m_Log.Write("Lycos.js : idCheck - wrong id");
                this.m_DomainManager.newDomainForProtocol(szDomain, szProtocol, szWantedContentID);
            }
        }
        else
        {
            this.m_Log.Write("Lycos.js : idCheck - not found");
            this.m_DomainManager.newDomainForProtocol(szDomain, szProtocol, szWantedContentID);
        }

        this.m_Log.Write("Lycos.js : idCheck - END");
    },



    windowCount : function()
    {
        try
        {
            this.m_Log.Write("OWA.js : windowCount - START");

            var iWindowCount = 0;
            var winman = Components.classes["@mozilla.org/appshell/window-mediator;1"];
            winman = winman.getService(Components.interfaces.nsIWindowMediator);
            var e = winman.getEnumerator(null);

            while (e.hasMoreElements())
            {
                var win = e.getNext();
                win.QueryInterface(Components.interfaces.nsIDOMWindowInternal);
                var szValue = win.document.documentElement.getAttribute("id");
                this.m_Log.Write("OWA.js : windowCount - "+ szValue);

                if (szValue =="messengerWindow")iWindowCount++;
            }

            this.m_Log.Write("OWA.js : windowCount - "+ iWindowCount +" END ");
            return iWindowCount;
        }
        catch(e)
        {
            this.m_Log.DebugDump("OWA.js : Exception in windowCount "
                                            + e.name
                                            + ".\nError message: "
                                            + e.message);
        }
    },
};
